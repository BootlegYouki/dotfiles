local vars = require("variables")
local fn   = require("utils.functions")


-- Flags
local locked           = { locked = true }
local mouse            = { mouse = true }
local release          = { release = true }
local repeating        = { repeating = true }
local locked_repeating = { locked = true, repeating = true }

local function normalise_keybind(key)
    return key:gsub("%s+", ""):lower()
end

local function repeating_unless_mouse(key)
    return not normalise_keybind(key):find("mouse", 1, true) and repeating or nil
end

local function flatten_keybinds(keybinds, keys)
    keys = keys or {}

    if type(keybinds) == "table" then
        for _, keybind in ipairs(keybinds) do
            flatten_keybinds(keybind, keys)
        end
    elseif keybinds ~= nil and keybinds ~= "" then
        keys[#keys + 1] = keybinds
    end

    return keys
end

local function create_bind(keybinds, action, flags)
    local get_flags = type(flags) == "function" and flags or function()
        return flags
    end

    for _, key in ipairs(flatten_keybinds(keybinds)) do
        hl.bind(key, action, get_flags(key))
    end
end

-- Launcher
local launcher_default = normalise_keybind("SUPER + SUPER_L")
create_bind(
    vars.kbLauncher,
    hl.dsp.global("caelestia:launcher"),
    function(key)
        return normalise_keybind(key) == launcher_default and release or nil
    end
)

-- Misc
create_bind(vars.kbSession, hl.dsp.global("caelestia:session"))
create_bind(vars.kbShowSidebar, hl.dsp.global("caelestia:sidebar"))
create_bind(vars.kbClearNotifs, hl.dsp.global("caelestia:clearNotifs"), locked)
create_bind(vars.kbShowPanels, hl.dsp.global("caelestia:showall"))
create_bind(vars.kbLock, hl.dsp.exec_cmd("caelestia shell lock lock"))

-- Restore lock
create_bind(vars.kbRestoreLock, function()
    hl.dispatch(hl.dsp.exec_cmd("caelestia shell -d"))
    hl.dispatch(hl.dsp.exec_cmd("caelestia shell lock lock"))
end)

-- Kill/restart
create_bind("CTRL + SUPER + SHIFT + R", hl.dsp.exec_cmd("qs -c caelestia kill"), release)
create_bind(
    "CTRL + SUPER + ALT + R",
    hl.dsp.exec_cmd("qs -c caelestia kill; sleep .1; caelestia shell -d"),
    release
)

for i = 1, 10 do
    local key = i % 10 -- 10 maps to key 0
    create_bind(vars.kbGoToWs .. " + " .. key, fn.wsaction("focus", "", i))
    create_bind(vars.kbMoveWinToWs .. " + " .. key, fn.wsaction("move", "", i))
    create_bind(vars.kbGoToWsGroup .. " + " .. key, fn.wsaction("focus", "group", i))
    create_bind(vars.kbMoveWinToWsGroup .. " + " .. key, fn.wsaction("move", "group", i))
end

-- Go to workspace -1/+1
create_bind(vars.kbPrevWs, fn.relative_ws(-1), repeating_unless_mouse)
create_bind(vars.kbNextWs, fn.relative_ws(1), repeating_unless_mouse)

-- Go to workspace group -1/+1
create_bind(vars.kbPrevWsGroup, fn.relative_ws(-10), repeating_unless_mouse)
create_bind(vars.kbNextWsGroup, fn.relative_ws(10), repeating_unless_mouse)

-- Move window to workspace -1/+1
create_bind(vars.kbMoveWinToWsNext, hl.dsp.window.move({ workspace = "+1" }), repeating_unless_mouse)
create_bind(vars.kbMoveWinToWsPrev, hl.dsp.window.move({ workspace = "-1" }), repeating_unless_mouse)

-- Move window to/from special workspace
create_bind(vars.kbMoveWinToWsSpecial, hl.dsp.window.move({ workspace = "special:special" }))
create_bind(vars.kbMoveWinFromWsSpecial, hl.dsp.window.move({ workspace = "e+0" }))

-- Mouse monitor toggle (ALT + TAB → moves mouse between monitors)
create_bind(vars.kbMouseMonitorToggle, function()
    local active_mon = hl.get_active_monitor()
    if active_mon then
        if active_mon.id == 0 then
            local ws1 = hl.get_active_workspace(1)
            if ws1 then
                hl.dispatch(hl.dsp.focus({ workspace = ws1.id }))
            end
        else
            local ws0 = hl.get_active_workspace(0)
            if ws0 then
                hl.dispatch(hl.dsp.focus({ workspace = ws0.id }))
            end
        end
    end
end)

-- Window groups
create_bind(vars.kbWindowCycleNext, hl.dsp.window.cycle_next(), repeating)
create_bind(vars.kbWindowCyclePrev, hl.dsp.window.cycle_next({ next = false }), repeating)
create_bind(vars.kbWindowGroupCycleNext, hl.dsp.group.next(), repeating)
create_bind(vars.kbWindowGroupCyclePrev, hl.dsp.group.prev(), repeating)
create_bind(vars.kbToggleGroup, hl.dsp.group.toggle())
create_bind(vars.kbUngroup, hl.dsp.window.move({ out_of_group = true }))
create_bind(vars.kbGroupLockActive, hl.dsp.group.lock_active())

-- Window actions
for _, dir in ipairs({ "left", "right", "up", "down" }) do
    create_bind({ "SUPER + " .. dir, "SUPER + SHIFT + " .. dir }, hl.dsp.window.move({ direction = dir }))
end

create_bind(vars.kbWindowDecreaseWidth, fn.resize_active_window(-10, 0), repeating)
create_bind(vars.kbWindowIncreaseWidth, fn.resize_active_window(10, 0), repeating)
create_bind(vars.kbWindowDecreaseHeight, fn.resize_active_window(0, -10), repeating)
create_bind(vars.kbWindowIncreaseHeight, fn.resize_active_window(0, 10), repeating)

create_bind({ vars.kbMoveWindow, "SUPER + mouse:272" }, hl.dsp.window.drag(), mouse)
create_bind({ vars.kbResizeWindow, "SUPER + mouse:273" }, hl.dsp.window.resize(), mouse)
create_bind(vars.kbCenterWindow, hl.dsp.window.center())
create_bind(vars.kbNormalizeWindow, function()
    hl.dispatch(hl.dsp.window.resize(fn.resize_by_screen(55, 70)))
    hl.dispatch(hl.dsp.window.center())
end)
create_bind(vars.kbWindowPip, function()
    local a = hl.get_active_window()
    if a then
        local pip = fn.move_actions(a) or {}
        if not a.floating then table.insert(pip, 1, hl.dsp.window.float()) end
        table.insert(pip, hl.dsp.window.pin({ action = "on", window = "address:" .. a.address }))

        for _, x in ipairs(pip) do
            hl.dispatch(x)
        end
    end
end)
create_bind(vars.kbPinWindow, hl.dsp.window.pin())
create_bind(vars.kbWindowFullscreen, hl.dsp.window.fullscreen({ mode = "fullscreen" }))
create_bind(vars.kbWindowBorderedFullscreen, hl.dsp.window.fullscreen({ mode = "maximized" }))
create_bind(vars.kbToggleWindowFloating, function()
    local win = hl.get_active_window()
    if not win then return end

    if win.fullscreen and win.fullscreen > 0 then
        hl.dispatch(hl.dsp.window.fullscreen({ action = "unset", mode = "maximized" }))
        hl.dispatch(hl.dsp.window.fullscreen({ action = "unset", mode = "fullscreen" }))
    end

    if win.floating then
        -- Snap back into tiling management layout
        hl.dispatch(hl.dsp.window.float({ action = "off" }))
    else
        -- Float the window, give it a comfortable size, and center it
        hl.dispatch(hl.dsp.window.float({ action = "on" }))
        local screen = hl.get_active_monitor()
        if screen and screen.width and screen.height then
            local scale = (type(screen.scale) == "number" and screen.scale > 0) and screen.scale or 1
            local w = math.floor((screen.width / scale) * 0.65)
            local h = math.floor((screen.height / scale) * 0.75)
            hl.dispatch(hl.dsp.window.resize({ x = w, y = h, relative = false }))
        end
        hl.dispatch(hl.dsp.window.center())
    end
end)
create_bind(vars.kbCloseWindow, hl.dsp.window.close())

-- Special workspace toggles
create_bind(vars.kbSpecialWs, fn.toggle("specialws"))
create_bind(vars.kbSystemMonitorWs, fn.toggle("sysmon"))
create_bind(vars.kbMusicWs, fn.toggle("music"))
create_bind(vars.kbCommunicationWs, fn.toggle("communication"))
create_bind(vars.kbTodoWs, fn.toggle("todo"))
create_bind(vars.kbDevWs, fn.toggle("dev"))

-- Apps
create_bind(vars.kbTerminal, hl.dsp.exec_cmd(vars.terminal))
create_bind(vars.kbBrowser, hl.dsp.exec_cmd(vars.browser))
create_bind(vars.kbFileExplorer, hl.dsp.exec_cmd(vars.fileExplorer))
create_bind(vars.kbAudioSettings, hl.dsp.exec_cmd(vars.audioSettings))
create_bind(vars.kbSettings, hl.dsp.exec_cmd(vars.settings))

-- Utilities
create_bind(vars.kbScreenshot, hl.dsp.exec_cmd(os.getenv("HOME") .. "/.config/hypr/scripts/screenshot.sh fullscreen"), locked)
create_bind(vars.kbScreenshotFreeze, hl.dsp.global("caelestia:screenshotFreezeClip"))
create_bind(vars.kbScreenshotRegion, hl.dsp.global("caelestia:screenshotFreezeClip"))
create_bind(vars.kbRecord, hl.dsp.exec_cmd("caelestia record"))
create_bind(vars.kbRecordSound, hl.dsp.exec_cmd("caelestia record -s"))
create_bind(vars.kbRecordRegion, hl.dsp.exec_cmd("caelestia record -r"))
create_bind(vars.kbColorPicker, hl.dsp.exec_cmd("hyprpicker -a"))
create_bind("SUPER + ALT + A", hl.dsp.exec_cmd("autostart-manager"))

-- Brightness
create_bind("XF86MonBrightnessUp", hl.dsp.global("caelestia:brightnessUp"), locked)
create_bind("XF86MonBrightnessDown", hl.dsp.global("caelestia:brightnessDown"), locked)

-- Media
create_bind({ vars.kbMediaToggle, "XF86AudioPlay", "XF86AudioPause" }, hl.dsp.global("caelestia:mediaToggle"), locked)
create_bind({ vars.kbMediaNext, "XF86AudioNext" }, hl.dsp.global("caelestia:mediaNext"), locked)
create_bind({ vars.kbMediaPrev, "XF86AudioPrev" }, hl.dsp.global("caelestia:mediaPrev"), locked)
create_bind({ vars.kbMediaStop, "XF86AudioStop" }, hl.dsp.global("caelestia:mediaStop"), locked)

-- Volume
create_bind({ vars.kbVolumeMute, "XF86AudioMute" }, hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"), locked)
create_bind("XF86AudioMicMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle"), locked)
create_bind(
    "XF86AudioRaiseVolume",
    hl.dsp.exec_cmd(
        "wpctl set-mute @DEFAULT_AUDIO_SINK@ 0; wpctl set-volume -l " ..
        (vars.volumeMax / 100) .. " @DEFAULT_AUDIO_SINK@ " .. vars.volumeStep .. "%+"
    ),
    locked_repeating
)
create_bind(
    "XF86AudioLowerVolume",
    hl.dsp.exec_cmd(
        "wpctl set-mute @DEFAULT_AUDIO_SINK@ 0; wpctl set-volume @DEFAULT_AUDIO_SINK@ " .. vars.volumeStep .. "%-"
    ),
    locked_repeating
)

-- Sleep
create_bind(vars.kbSleep, hl.dsp.exec_cmd(vars.sleepGestureCmd), locked)

-- Clipboard & Universal Copy/Paste
local terminal_classes = {
    ["ghostty"] = true,
    ["com.mitchellh.ghostty"] = true,
    ["kitty"] = true,
    ["alacritty"] = true,
    ["foot"] = true,
    ["footclient"] = true,
    ["wezterm"] = true,
    ["org.wezfurlong.wezterm"] = true,
    ["xterm"] = true,
    ["urxvt"] = true,
    ["rxvt"] = true,
    ["gnome-terminal"] = true,
    ["org.gnome.terminal"] = true,
    ["konsole"] = true,
    ["org.kde.konsole"] = true,
    ["tilix"] = true,
    ["terminator"] = true,
    ["xfce4-terminal"] = true,
    ["rio"] = true,
}

local function is_terminal(win)
    if not win or not win.class then return false end
    local class = win.class:lower()
    if terminal_classes[class] then return true end
    for term, _ in pairs(terminal_classes) do
        if class:find(term, 1, true) then return true end
    end
    return false
end

local function universal_copy()
    local win = hl.get_active_window()
    local mods = is_terminal(win) and "CTRL SHIFT" or "CTRL"
    hl.dispatch(hl.dsp.send_key_state({ mods = mods, key = "c", state = "down" }))
    hl.dispatch(hl.dsp.send_key_state({ mods = mods, key = "c", state = "up" }))
end

local function universal_paste()
    local win = hl.get_active_window()
    local mods = is_terminal(win) and "CTRL SHIFT" or "CTRL"
    hl.dispatch(hl.dsp.send_key_state({ mods = mods, key = "v", state = "down" }))
    hl.dispatch(hl.dsp.send_key_state({ mods = mods, key = "v", state = "up" }))
end

create_bind(vars.kbCopy, universal_copy)
create_bind(vars.kbPaste, universal_paste)
create_bind(vars.kbClipboard, hl.dsp.exec_cmd("pkill fuzzel || caelestia clipboard"))
create_bind(vars.kbClipboardDel, hl.dsp.exec_cmd("pkill fuzzel || caelestia clipboard -d"))
create_bind(
    vars.kbClipboardPasteLatest,
    hl.dsp.exec_cmd('sleep 0.5s && ydotool type -d 1 "$(cliphist list | head -1 | cliphist decode)"'),
    locked
)

-- Wallpaper shift (Super + , and Super + .)
create_bind(vars.kbWallpaperPrev, hl.dsp.exec_cmd("caelestia-wallpaper-shift prev"))
create_bind(vars.kbWallpaperNext, hl.dsp.exec_cmd("caelestia-wallpaper-shift next"))


-- Testing
create_bind(
    "SUPER + ALT + F12",
    hl.dsp.exec_cmd(
        "notify-send -u low -i dialog-information-symbolic 'Test notification' " ..
        [["Here's a really long message to test truncation and wrapping\nYou can middle click or flick this notification to dismiss it!"]] ..
        " -a 'Shell' -A 'Test1=I got it!' -A 'Test2=Another action'"
    )
)
