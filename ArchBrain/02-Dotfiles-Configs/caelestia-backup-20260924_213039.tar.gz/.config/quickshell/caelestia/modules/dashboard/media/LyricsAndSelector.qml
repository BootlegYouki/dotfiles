import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Services.Mpris
import Caelestia.Blobs
import Caelestia.Config
import qs.components
import qs.components.controls
import qs.services

Item {
    ColumnLayout {
        id: layout

        anchors.fill: parent
        anchors.leftMargin: Tokens.padding.medium
        spacing: Tokens.spacing.medium

        RowLayout {
            Layout.bottomMargin: -Tokens.spacing.medium
            spacing: Tokens.spacing.medium
            z: 1

            MaterialIcon {
                Layout.topMargin: Math.round(fontInfo.pointSize * 0.12)
                text: "lyrics"
                fontStyle: Tokens.font.icon.medium
            }

            StyledText {
                Layout.fillWidth: true
                text: qsTr("Lyrics")
                font: Tokens.font.title.medium
            }

            Item {
                id: modeBtnItem

                implicitWidth: modeBtn.implicitWidth * 0.9
                implicitHeight: modeBtn.implicitHeight * 0.9

                BlobGroup {
                    id: modeBlobGroup

                    color: Colours.palette.m3surfaceContainerHighest
                    smoothing: Tokens.rounding.medium
                    cornerFill: false

                    Behavior on color {
                        CAnim {}
                    }
                }

                BlobRect {
                    id: modeBtnRect

                    anchors.fill: parent
                    anchors.margins: !modeBtn.pressed && modeBtn.containsMouse ? -Tokens.padding.extraSmall : 0
                    group: modeBlobGroup
                    radius: Tokens.rounding.medium

                    Behavior on anchors.margins {
                        Anim {}
                    }
                }

                MouseArea {
                    id: modeBtn

                    anchors.centerIn: parent
                    implicitWidth: implicitHeight
                    implicitHeight: modeIcon.implicitHeight + Tokens.padding.extraSmall * 2
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: Romaji.cycleMode()

                    MaterialIcon {
                        id: modeIcon

                        anchors.centerIn: parent
                        text: Romaji.mode === "english" ? "translate" : Romaji.mode === "romaji" ? "subtitles" : "text_fields"
                        fontStyle: Tokens.font.icon.medium
                    }
                }
            }

            Item {
                id: floatBtnItem

                implicitWidth: floatBtn.implicitWidth * 0.9
                implicitHeight: floatBtn.implicitHeight * 0.9

                BlobGroup {
                    id: floatBlobGroup

                    color: FloatingLyrics.open ? Colours.palette.m3primaryContainer : Colours.palette.m3surfaceContainerHighest
                    smoothing: Tokens.rounding.medium
                    cornerFill: false

                    Behavior on color {
                        CAnim {}
                    }
                }

                BlobRect {
                    id: floatBtnRect

                    anchors.fill: parent
                    anchors.margins: !floatBtn.pressed && floatBtn.containsMouse ? -Tokens.padding.extraSmall : 0
                    group: floatBlobGroup
                    radius: Tokens.rounding.medium

                    Behavior on anchors.margins {
                        Anim {}
                    }
                }

                MouseArea {
                    id: floatBtn

                    anchors.centerIn: parent
                    implicitWidth: implicitHeight
                    implicitHeight: floatIcon.implicitHeight + Tokens.padding.extraSmall * 2
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: {
                        FloatingLyrics.toggle();
                        if (FloatingLyrics.open) {
                            const state = ShellState.forActive();
                            if (state)
                                state.dashboard = false;
                        }
                    }

                    MaterialIcon {
                        id: floatIcon

                        anchors.centerIn: parent
                        text: "picture_in_picture_alt"
                        color: FloatingLyrics.open ? Colours.palette.m3onPrimaryContainer : Colours.palette.m3onSurface
                        fontStyle: Tokens.font.icon.medium
                    }
                }
            }
        }

        LyricList {
            Layout.fillWidth: true
            Layout.fillHeight: true
        }

        SplitButton {
            Layout.alignment: Qt.AlignHCenter

            type: SplitButton.Tonal
            disabled: !Players.list.length
            active: menuItems.find(m => m.modelData === Players.active) ?? menuItems[0] ?? null
            menu.onItemSelected: item => Players.manualActive = (item as PlayerItem).modelData

            menuItems: playerList.instances
            fallbackIcon: "music_off"
            fallbackText: qsTr("No players")

            minLeftWidth: layout.width - expandBtn.implicitWidth - spacing
            label.Layout.maximumWidth: minLeftWidth - iconLabel.implicitWidth - textRow.spacing - textRow.anchors.horizontalCenterOffset / 2 - horizontalPadding * 2
            label.elide: Text.ElideRight

            stateLayer.disabled: true
            menuOnTop: true

            Variants {
                id: playerList

                model: Players.list

                PlayerItem {}
            }
        }
    }

    component PlayerItem: MenuItem {
        required property MprisPlayer modelData

        icon: modelData === Players.active ? "check" : ""
        text: Players.getIdentity(modelData)
        activeIcon: "animated_images"
    }
}
