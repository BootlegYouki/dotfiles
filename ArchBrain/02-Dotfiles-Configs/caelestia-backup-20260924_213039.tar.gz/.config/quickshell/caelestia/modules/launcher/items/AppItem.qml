import QtQuick
import Quickshell
import Quickshell.Widgets
import Caelestia.Config
import qs.components
import qs.components.controls
import qs.services
import qs.utils
import qs.modules.launcher.services

Item {
    id: root

    property var list: null
    required property DesktopEntry modelData
    required property ScreenState screenState

    implicitHeight: Tokens.sizes.launcher.itemHeight

    anchors.left: parent?.left
    anchors.right: parent?.right

    StateLayer {
        radius: Tokens.rounding.large
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton) {
                if (root.list?.activeMenu && root.list.activeMenu !== contextMenu)
                    root.list.activeMenu.expanded = false;
                if (root.list)
                    root.list.activeMenu = contextMenu;
                contextMenu.expanded = true;
            } else {
                if (root.list?.activeMenu)
                    root.list.activeMenu.expanded = false;
                Apps.launch(root.modelData);
                root.screenState.launcher = false;
            }
        }
    }

    Item {
        anchors.fill: parent
        anchors.leftMargin: Tokens.padding.medium
        anchors.rightMargin: Tokens.padding.medium
        anchors.margins: Tokens.padding.small

        IconImage {
            id: icon

            asynchronous: true
            source: Quickshell.iconPath(root.modelData?.icon, "image-missing")
            implicitSize: parent.height * 0.8

            anchors.verticalCenter: parent.verticalCenter
        }

        Item {
            anchors.left: icon.right
            anchors.leftMargin: Tokens.spacing.medium
            anchors.verticalCenter: icon.verticalCenter

            implicitWidth: parent.width - icon.width - favouriteIcon.width
            implicitHeight: name.implicitHeight + comment.implicitHeight

            StyledText {
                id: name

                text: root.modelData?.name ?? ""
                font: Tokens.font.body.medium
            }

            StyledText {
                id: comment

                text: (root.modelData?.comment || root.modelData?.genericName || root.modelData?.name) ?? ""
                font: Tokens.font.body.small
                color: Colours.palette.m3outline

                elide: Text.ElideRight
                width: root.width - icon.width - favouriteIcon.width - Tokens.rounding.extraLargeIncreased

                anchors.top: name.bottom
            }
        }

        Loader {
            id: favouriteIcon

            asynchronous: true
            anchors.verticalCenter: parent.verticalCenter
            anchors.right: parent.right
            active: root.modelData && Strings.testRegexList(GlobalConfig.launcher.favouriteApps, root.modelData.id)

            sourceComponent: MaterialIcon {
                text: "favorite"
                fill: 1
                color: Colours.palette.m3primary
            }
        }
    }

    Menu {
        id: contextMenu

        onExpandedChanged: {
            if (!expanded && root.list?.activeMenu === contextMenu)
                root.list.activeMenu = null;
        }

        attachTo: root
        attachSideX: Menu.Right
        thisSideX: Menu.Right
        attachSideY: Menu.Bottom
        thisSideY: Menu.Top
        marginX: -Tokens.padding.medium
        marginY: Tokens.spacing.extraSmall

        items: [
            MenuItem {
                text: qsTr("Run")
                icon: "play_arrow"
                onClicked: {
                    contextMenu.expanded = false;
                    Apps.launch(root.modelData);
                    root.screenState.launcher = false;
                }
            },
            MenuItem {
                text: qsTr("Locate Folder")
                icon: "folder_open"
                onClicked: {
                    contextMenu.expanded = false;
                    root.screenState.launcher = false;
                    Quickshell.execDetached(["caelestia-app-action", "locate", root.modelData.id]);
                }
            },
            MenuItem {
                text: qsTr("Hide from Menu")
                icon: "visibility_off"
                onClicked: {
                    contextMenu.expanded = false;
                    const apps = GlobalConfig.launcher.hiddenApps;
                    GlobalConfig.launcher.hiddenApps = [...apps, root.modelData.id];
                }
            },
            MenuItem {
                text: qsTr("Uninstall")
                icon: "delete"
                onClicked: {
                    contextMenu.expanded = false;
                    root.screenState.launcher = false;
                    Quickshell.execDetached(["ghostty", "-e", "caelestia-app-action", "uninstall", root.modelData.id]);
                }
            }
        ]
    }

    Connections {
        target: root.screenState
        function onLauncherChanged(): void {
            if (!root.screenState.launcher)
                contextMenu.expanded = false;
        }
    }
}
