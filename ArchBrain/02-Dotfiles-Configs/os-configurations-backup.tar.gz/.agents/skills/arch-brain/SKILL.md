---
name: arch-brain
description: Mandatory reference and workflow guide for inspecting, querying, and updating the ArchBrain Obsidian vault (/home/bootlegyouki/ArchBrain/) whenever handling Linux, Arch Linux, Hyprland, Caelestia, dotfiles, or system troubleshooting tasks.
---

# ArchBrain Knowledge Base & Obsidian Workflow Skill

## Core Identity & Purpose
`ArchBrain` located at `/home/bootlegyouki/ArchBrain/` is **Antigravity's persistent system memory bank**. 

Because Arch Linux and CachyOS configurations can be complex for the user, Antigravity uses `ArchBrain` as an authoritative Obsidian vault to store every system tweak, package installation step, custom keybinding, thermal fix, and gaming optimization.

---

## Vault Structure & Organization
- **`01-Cheatsheets/`**: System cheat sheets, gaming installation guides (Steam, Overwatch 2, Genshin Impact), power/battery limits, CLI shortcuts, and service commands.
- **`02-Dotfiles-Configs/`**: Configuration documentation for Hyprland ([`desktop-caelestia-hyprland.md`](file:///home/bootlegyouki/ArchBrain/02-Dotfiles-Configs/desktop-caelestia-hyprland.md)), Caelestia Shell, Waybar, Ghostty, Fish/Starship, Thunar, etc.
- **`03-Troubleshooting/`**: Solutions to previously encountered issues (Discord splash screen UI indicators, laptop thermal management, disk full fixes).
- **`04-Package-Log/`**: Installed tools, gaming dependencies, and environment notes.

---

## Obsidian Note Conventions & Formatting Rules

### 1. Markdown Headers & Hierarchy
Every note must start with a single `# Title` followed by structured `## Subsections` and `### Bullet Points`.

### 2. Obsidian `[[WikiLinks]]` Graph Connectivity
Every note must link to related notes at the bottom of the file to maintain graph consistency:
```markdown
## Related Notes
- [[gaming-genshin-impact-cachyos]]
- [[btrfs-live-partition-expansion]]
```

### 3. GitHub & Obsidian Alerts
Use callout blocks for important warnings or context:
```markdown
> [!NOTE]
> System sleep inhibitor is active during downloads.

> [!WARNING]
> Do not use third-party DLL injectors or memory mods in Genshin.
```

---

## Mandatory AI Execution Rules
1. **Inspect Vault First**: Always search `/home/bootlegyouki/ArchBrain/` (`grep_search` or `view_file`) before forming diagnostic hypotheses or modifying configuration files.
2. **Token Efficiency**: Read targeted line ranges (20-50 lines) rather than dumping full directories.
3. **Auto-Document Fixes**: After completing any system configuration change, driver fix, or software setup, write or update the corresponding note in `ArchBrain`.
4. **UWSM Session Awareness**: Always launch application commands via UWSM (`uwsm app -- <cmd>`) under Hyprland.
