# Arch Linux System Memory & Primary AI Guidance (CachyOS + Caelestia + UWSM)

## Overview & Core System Role
The user relies on Antigravity to act as the primary System Administrator and guide for this CachyOS (Arch Linux) system.

`ArchBrain` (`/home/bootlegyouki/ArchBrain`) is **Antigravity's persistent system memory**. It stores all technical cheat sheets, system rules, package dependencies, dotfile mappings, thermal guides, and troubleshooting history so that the user never has to struggle with raw Arch Linux complexities alone.

## System Environment Context
- **Distribution**: CachyOS (Arch Linux derivative with x86-64-v3/v4 optimized repos & `linux-cachyos` kernel)
- **Session Manager**: UWSM (Universal Wayland Session Manager)
- **Desktop Environment**: Caelestia Shell (powered by Quickshell) + Hyprland v0.56.2
- **Key Configuration Paths**:
  - Vault Root: `/home/bootlegyouki/ArchBrain/`
  - Hyprland Configs: `~/.config/hypr/` (`hyprland.lua`, `keybinds.lua`, `variables.lua`, `rules.lua`)
  - Caelestia Shell Configs: `~/.config/caelestia/` & `~/.config/quickshell/caelestia/`
  - UWSM Session Configs: `~/.config/uwsm/` (`env`, `env-hyprland`)
  - Shell: `~/.config/fish/config.fish` & Starship prompt

## Mandatory Rules for AI Assistant
Whenever answering questions, executing terminal commands, troubleshooting, or modifying system configurations:

1. **Be the Dedicated Arch Linux Specialist**:
   - Understand that Arch Linux can be complex for the user. Proactively handle command execution, dependency checking, driver setup, and optimization steps so the user doesn't have to navigate Arch alone.

2. **ALWAYS Check ArchBrain First**:
   - Before forming hypotheses, diagnosing bugs, or recommending commands, inspect `/home/bootlegyouki/ArchBrain/` (specifically `01-Cheatsheets/`, `02-Dotfiles-Configs/`, `03-Troubleshooting/`, and `04-Package-Log/`).
   - Re-use recorded solutions, keybindings, and gaming configurations stored in `ArchBrain`.

3. **Environment & Tooling Awareness**:
   - **UWSM**: Always use `uwsm app -- <cmd>` when launching graphical applications, autostart items, or background GUI daemons under Wayland.
   - **Caelestia Shell IPC**: Use `caelestia shell ...` commands (e.g., `caelestia shell drawers toggle sidebar`) for interacting with desktop widgets and drawers.
   - **CachyOS Repos**: Always prefer CachyOS optimized repos (`pacman -Syu`, `cachyos-rate-mirrors`) and package managers (`pacman`, `paru`).

4. **Auto-Document Fixes & System Changes**:
   - After resolving any system issue, driver configuration error, gaming setup, or desktop bug, create or update a dedicated note in `/home/bootlegyouki/ArchBrain/`.
   - Maintain internal Obsidian `[[links]]` across all notes to ensure knowledge graph consistency.
